---------------------------------------------------------------------------
-- This Widgets script is the starter script used throughout my YouTube tutorial on creating gauges and speedometers in EdgeTX Lua widgets.
-- This script includes the basic structure for coding EdgeTX widgets.
-- By Moshir Fakhoury (Flywithmoshirrc)
-- Last Edited 21/07/2026
---------------------------------------------------------------------------

local name = "Gauge2"

---------------------------------------------------------------------------
-- OPTIONS
---------------------------------------------------------------------------
local options = {}

---------------------------------------------------------------------------
-- CREATE
---------------------------------------------------------------------------

local function create(zone, opts)
  return {zone = zone, options = opts or {}}
end

---------------------------------------------------------------------------
-- UPDATE
---------------------------------------------------------------------------

local function update(widget, opts)
  widget.options = opts
end

---------------------------------------------------------------------------
-- REFRESH
---------------------------------------------------------------------------

local function refresh(widget)

  local z = widget.zone
  local opt = widget.options

  lcd.drawFilledRectangle(z.x, z.y, z.w, z.h, BLACK)



end

---------------------------------------------------------------------------
-- RETURN
---------------------------------------------------------------------------

return {
  name = name,
  create = create,
  refresh = refresh,
  update = update,
  options = options
}